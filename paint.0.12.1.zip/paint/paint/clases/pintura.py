import tkinter as tk

class Pintura:
    def __init__(self, master):
        self.master = master
        self.palette = ["red", "blue", "green", "yellow", "orange", "purple", "black", "white"]
        self.create_color_palette()

    def create_color_palette(self):
        self.palette_frame = tk.Frame(self.master, bg="white", width=50, height=200)
        self.palette_frame.place(x=2020, y=0)

        for i, color in enumerate(self.palette):
            color_button = tk.Button(self.palette_frame, bg=color, width=4, height=1, command=lambda c=color: self.change_color(c))
            color_button.grid(row=i, column=0, padx=5, pady=5)

        self.master.bind("<Enter>", self.change_cursor_hand)
        self.master.bind("<Leave>", self.change_cursor_arrow)

    def change_color(self, color):
        global selected_color
        selected_color = color

    def change_cursor_hand(self, event):
        self.master.config(cursor="hand2")

    def change_cursor_arrow(self, event):
        self.master.config(cursor="")



