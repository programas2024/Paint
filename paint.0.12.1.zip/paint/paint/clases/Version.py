import tkinter as tk
from Tooltip import Tooltip

class version:
    def __init__(self, parent):
        self.parent = parent
        self.ventana = tk.Toplevel(parent)
        self.ventana.title("Versión")
        self.ventana.geometry("520x700")
        
        self.ventana.transient(parent)  # Establece la ventana principal como el padre
        self.ventana.grab_set()  # Bloquea el foco en esta ventana

        self.canvas = tk.Canvas(self.ventana, bg="white", width=520, height=700)
        self.canvas.pack()

        self.imagen4= tk.PhotoImage(file="paint/imagenes/salida.png")

        version_label = tk.Label(self.canvas, text="Versión 0.1.12", font=("Arial", 14), background="white")
        version_label.place(x=240, y=20, anchor="center")

        creadores_label = tk.Label(self.canvas, text="Creadores:" ,font=("Arial", 14), background="white")
        creadores_label.place(x=240, y=50, anchor="center")

        creadores_label = tk.Label(self.canvas, text="Juan esteban Molina Diaz y Jhonnatan Ceron Amariles", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=90, anchor="center")

        creadores_label = tk.Label(self.canvas, text="Contactos:" ,font=("Arial", 14), background="white")
        creadores_label.place(x=240, y=130, anchor="center")

        creadores_label = tk.Label(self.canvas, text="juan.esteban.molina@correounivalle.edu.co", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=170, anchor="center")

        creadores_label = tk.Label(self.canvas, text="jhonnatan.ceron@correounivalle.edu.co", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=210, anchor="center")

        creadores_label = tk.Label(self.canvas, text="Descripcion", font=("Arial", 14), background="white")
        creadores_label.place(x=240, y=250, anchor="center")

        creadores_label = tk.Label(self.canvas, text="La aplicacion esta diseñada para hacer uso de tu creatividad en tu dia", font=("Arial", 12), background="white")
        creadores_label.place(x=243, y=290, anchor="center")

        creadores_label = tk.Label(self.canvas, text="colorea lo que quieras con toda la libertad y confianza", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=330, anchor="center")

        creadores_label = tk.Label(self.canvas, text="Cuenta  con herramientas poderosas para tus diseños  ", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=370, anchor="center")

        creadores_label = tk.Label(self.canvas, text="sera tu placer artistico  de cada dia.   ", font=("Arial", 12), background="white")
        creadores_label.place(x=240, y=410, anchor="center")

        creadores_label = tk.Label(self.canvas, text="En la proxima  ", font=("Arial", 14), background="white")
        creadores_label.place(x=240, y=450, anchor="center")

        creadores_label = tk.Label(self.canvas, text=" - Se actualizara más variedad de planillas entre basicas y avanzadas ", font=("Arial", 10), background="white")
        creadores_label.place(x=240, y=490, anchor="center")

        creadores_label = tk.Label(self.canvas, text=" - Se actualizara con herramienas de escribir en mas tipos de letras ", font=("Arial", 10), background="white")
        creadores_label.place(x=240, y=540, anchor="center")

        creadores_label = tk.Label(self.canvas, text=" - Se solucionaran los errores actuales de la version 0.1.12 ", font=("Arial", 10), background="white")
        creadores_label.place(x=240, y=580, anchor="center")

        cerrar_boton = tk.Button(self.canvas, text="Cerrar",image=self.imagen4,border=0,background="white", command=self.cerrar)
        cerrar_boton.place(x=240, y=640, anchor="center")
        Tooltip(cerrar_boton,"Salir de version")


    def cerrar(self):
        self.ventana.destroy()