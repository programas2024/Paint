class Borrador:
    def __init__(self, canvas):
        self.canvas = canvas
        self.borrador_tamaño = 5
        self.borrando = False

    def get_borrador_tamaño(self):
        return self.borrador_tamaño

    def set_borrador_tamaño(self, tamaño):
        self.borrador_tamaño = tamaño

    def habilitar_borrador(self, tamaño):
        self.set_borrador_tamaño(tamaño)
        self.borrando = True
        self.canvas.bind("<B1-Motion>", self.borrar)
        self.canvas.bind("<ButtonRelease-1>", self.deshabilitar_borrador)

    def borrar(self, event):
        if self.borrando:
            x, y = event.x, event.y
            items = self.canvas.find_overlapping(x - self.borrador_tamaño, y - self.borrador_tamaño,
                                                 x + self.borrador_tamaño, y + self.borrador_tamaño)
            for item in items:
                self.canvas.delete(item)

    def deshabilitar_borrador(self, event=None):
        self.borrando = False
        self.canvas.unbind("<B1-Motion>")
        self.canvas.bind("<ButtonPress-1>", self.iniciar_dibujo)
        self.canvas.bind("<B1-Motion>", self.dibujar)
        self.canvas.bind("<ButtonRelease-1>", self.finalizar_dibujo)