import webbrowser
from tkinter import filedialog
from tkinter import messagebox
class Compartir:
    def __init__(self, parent):
        self.parent = parent

    def share_on_whatsapp(self):
        print("Compartir en WhatsApp")
        self.capture_and_share("WhatsApp")

    def share_on_facebook(self):
        print("Compartir en Facebook")
        self.capture_and_share("Facebook")

    def share_on_instagram(self):
        print("Compartir en Instagram")
        self.capture_and_share("Instagram")

    def capture_and_share(self, platform):
        # Preguntar al usuario si desea guardar antes de compartir
        if messagebox.askyesno("Guardar imagen", "¿Desea guardar la imagen antes de compartir?"):
            file_path = filedialog.asksaveasfilename(defaultextension='.png', filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
            if file_path:
                self.save_canvas(file_path)
                self.share_image(file_path, platform)
        else:
            # Si el usuario elige no guardar, simplemente comparte el lienzo actual
            self.share_image("", platform)

    def share_image(self, file_path, platform):
        if platform == "WhatsApp":
            whatsapp_url = "https://web.whatsapp.com/send?text=¡Mira esta imagen!&source=file://" + file_path.replace('\\', '/')
            webbrowser.open(whatsapp_url)
        elif platform == "Facebook":
            facebook_url = "https://www.facebook.com/sharer/sharer.php?u=file://" + file_path.replace('\\', '/')
            webbrowser.open(facebook_url)
        elif platform == "Instagram":
            instagram_url = "https://www.instagram.com/share?url=file://" + file_path.replace('\\', '/')
            webbrowser.open(instagram_url)

