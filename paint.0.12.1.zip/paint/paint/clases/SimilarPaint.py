import tkinter as tk
from tkinter import messagebox, filedialog
from PIL import ImageGrab
from SimilarTooltip import SimilarTooltip

class Paint:
    def __init__(self, root):
        self.root = root
        self.root.title("Paint")
        self.root.geometry("2000x700")  # Tamaño absoluto de la ventana
        self.root.configure(bg="white")  # Configurar el color de fondo de la ventana
        
        # Canvas
        self.canvas = tk.Canvas(self.root, width=800, height=700, bg="white")
        self.canvas.place(x=0, y=0)

        # Cargar imágenes
        self.imagen1 = tk.PhotoImage(file="imagenes/formas.png")
        self.imagen2 = tk.PhotoImage(file="imagenes/guardar.png")
        self.imagen3 = tk.PhotoImage(file="imagenes/letras.png")
        self.imagen4 = tk.PhotoImage(file="imagenes/mas.png")
        self.imagen5 = tk.PhotoImage(file="imagenes/portalapiz.png")
        self.imagen6 = tk.PhotoImage(file="imagenes/seleccion.png")
        self.imagen7 = tk.PhotoImage(file="imagenes/signo-de-interrogacion.png")
        self.imagen8 = tk.PhotoImage(file="imagenes/zoom.png")
        self.imagen9 = tk.PhotoImage(file="imagenes/borrador.png")
        self.imagen10 = tk.PhotoImage(file="imagenes/paleta-de-color.png")

        self.menu_formas = tk.Menu(self.root, tearoff=0)
        self.menu_formas.add_command(label="Cuadrado", command=lambda: self.seleccionar_forma("cuadrado"))
        self.menu_formas.add_command(label="Círculo", command=lambda: self.seleccionar_forma("circulo"))
        self.menu_formas.add_command(label="Triángulo", command=lambda: self.seleccionar_forma("triangulo"))
        self.menu_formas.add_command(label="Línea", command=lambda: self.seleccionar_forma("linea"))

        # Separator
        separator = tk.Frame(self.root, width=5, bg="gray")
        separator.place(x=800, y=0, height=700, width=5)

        # Botones dinámicos
        self.dynamic_buttons_frame = tk.Frame(self.root, bg="white")
        self.dynamic_buttons_frame.place(x=830, y=50, width=1500, height=1500)

        # Evento de clic del ratón para dibujar líneas
        self.canvas.bind("<ButtonPress-1>", self.iniciar_dibujo)
        self.canvas.bind("<B1-Motion>", self.dibujar)
        self.canvas.bind("<ButtonRelease-1>", self.finalizar_dibujo)

        # Ajustar el grosor del lápiz
        self.grosor_pincel = 1

        # Botón Ayuda
        ayuda_button = tk.Button(self.root, text="Ayuda", cursor="hand2", image=self.imagen7, background="white", border=0, command=self.mostrar_ayuda)
        ayuda_button.place(x=930, y=50, width=100)
        SimilarTooltip(ayuda_button, "Ayuda")

        # Botón Más opciones
        mas_opciones_button = tk.Button(self.root, text="Más opciones", cursor="hand2", image=self.imagen4, border=0, background="white", command=self.mostrar_mas_opciones)
        mas_opciones_button.place(x=1050, y=50, width=100)
        SimilarTooltip(mas_opciones_button, "Mas opciones")

         # Menubutton Pinceles con cascada
        self.pinceles_menubutton = tk.Menubutton(self.root, text="Pinceles", image=self.imagen5, border=0, cursor="hand2", relief=tk.RAISED, background="white")
        self.pinceles_menubutton.place(x=850, y=50)
        SimilarTooltip(self.pinceles_menubutton, "Pinceles")

        # Crear un menú secundario para la cascada de pinceles
        self.submenu_pinceles = tk.Menu(self.pinceles_menubutton, tearoff=0)
        self.pinceles_menubutton.config(menu=self.submenu_pinceles)
        
        # Agregar opciones de pinceles al menú
        self.submenu_pinceles.add_command(label="Pincel delgado", command=lambda: self.cambiar_pincel(1))
        self.submenu_pinceles.add_command(label="Pincel mediano", command=lambda: self.cambiar_pincel(3))
        self.submenu_pinceles.add_command(label="Pincel grueso", command=lambda: self.cambiar_pincel(6))

        # Variable para almacenar el estado de la escritura
        self.escribiendo = False
        self.texto_entry = None  # Entry para ingresar texto

         # Variable para almacenar la forma seleccionada
        self.forma_seleccionada = None
        self.forma_actual = None

        # Variables para el dibujo de formas
        self.x_inicial = None
        self.y_inicial = None

        # Variables para el ajuste de tamaño de la forma
        self.tamaño_forma = 50
        self.x_actual = None
        self.y_actual = None

        # Variables para la selección de objetos
        self.objeto_seleccionado = None
        self.x_inicial_seleccion = 0
        self.y_inicial_seleccion = 0

        # Crear menú contextual para las opciones de edición
        self.menu_contextual = tk.Menu(self.root, tearoff=0)
        self.menu_contextual.add_command(label="Editar")
        self.menu_contextual.add_command(label="Mover")
        self.menu_contextual.add_command(label="Eliminar")

        # Variable para el borrador
        self.borrando = False
        self.borrador_tamaño = 5

        self.pinceles_menubutton.focus_set()


    def mostrar_ayuda(self):
        messagebox.showinfo("Ayuda", "Aquí vendría la ayuda del programa.")

    def seleccionar_forma(self, forma):
        self.forma_seleccionada = forma

    def iniciar_dibujo(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        self.x_inicial = event.x
        self.y_inicial = event.y

    def dibujar(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        x_final = event.x
        y_final = event.y
        if x_final < 800:  
            self.canvas.create_line(self.x_inicial, self.y_inicial, x_final, y_final, width=self.grosor_pincel, fill="black")
            self.x_inicial = x_final

    def finalizar_dibujo(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        self.x_inicial = None
        self.y_inicial = None

    def mostrar_formas(self):
        # Crear un menú contextual con las opciones de formas
        self.menu_formas = tk.Menu(self.root, tearoff=0)
        self.menu_formas.add_command(label="Cuadrado", command=lambda: self.seleccionar_forma("cuadrado"))
        self.menu_formas.add_command(label="Círculo", command=lambda: self.seleccionar_forma("circulo"))
        self.menu_formas.add_command(label="Triángulo", command=lambda: self.seleccionar_forma("triangulo"))
        self.menu_formas.add_command(label="Línea", command=lambda: self.seleccionar_forma("linea"))

        # Mostrar el menú contextual de formas en la posición actual del cursor
        self.menu_formas.post(self.root.winfo_pointerx(), self.root.winfo_pointery())

        # Llamar al método focus para establecer el foco en el menú de pinceles
        self.focus("pinceles")

    def focus(self, widget):
        if widget == "pinceles":
            self.pinceles_menubutton.focus_set()
            # Desactivar el dibujo de formas y activar el dibujo del pincel
            self.canvas.bind("<ButtonPress-1>", self.iniciar_dibujo)
            self.canvas.bind("<B1-Motion>", self.dibujar)
            self.canvas.bind("<ButtonRelease-1>", self.finalizar_dibujo)
            # Eliminar el menú de formas si existe
            if hasattr(self, "menu_formas"):
                self.menu_formas.delete(0, "end")
        elif widget == "formas":
            self.menu_formas.focus_set()
            # Desactivar el dibujo del pincel y activar el dibujo de formas
            self.canvas.bind("<ButtonPress-1>", self.iniciar_dibujo_forma)
            self.canvas.bind("<B1-Motion>", self.dibujar_forma)
            self.canvas.bind("<ButtonRelease-1>", self.finalizar_dibujo_forma)
            # Crear el menú de formas si no existe
            if not hasattr(self, "menu_formas"):
                self.mostrar_formas()

    def mostrar_mas_opciones(self):
        # Borrar los botones anteriores
        for widget in self.dynamic_buttons_frame.winfo_children():
            widget.destroy()
        
        # Botones dinámicos
        guardar_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Guardar", image=self.imagen2, border=0, background="white", command=self.guardar_imagen)
        guardar_button.place(x=340, y=0, width=100)
        SimilarTooltip(guardar_button, "Guardar")

        letras_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Letras", image=self.imagen3, border=0, background="white", command=self.habilitar_escritura)
        letras_button.place(x=0, y=60, width=100)
        SimilarTooltip(letras_button, "Texto")

        seleccionar_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Seleccionar", image=self.imagen6, border=0, background="white")
        seleccionar_button.place(x=90, y=60, width=100)
        SimilarTooltip(seleccionar_button, "Seleccionar")

        self.formas_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Formas", image=self.imagen1, background="white", border=0,command=self.mostrar_formas)
        self.formas_button.place(x=220, y=60, width=100)
        SimilarTooltip(self.formas_button, "Formas")

        zoom_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Zoom", image=self.imagen8, border=0, background="white")
        zoom_button.place(x=340, y=60, width=100)
        SimilarTooltip(zoom_button, "Lupa")

        borrador_menubutton = tk.Menubutton(self.dynamic_buttons_frame, text="Borrador", image=self.imagen9, border=0, cursor="hand2", relief=tk.RAISED, background="white")
        borrador_menubutton.place(x=0, y=120, width=100)
        SimilarTooltip(borrador_menubutton, "Borrador")

        # Crear un menú secundario para la cascada de borrador
        submenu_borrador = tk.Menu(borrador_menubutton, tearoff=0)
        borrador_menubutton.config(menu=submenu_borrador)

        # Agregar opciones de borrador al menú
        submenu_borrador.add_command(label="Borrador pequeño", command=lambda: self.habilitar_borrador(5))
        submenu_borrador.add_command(label="Borrador mediano", command=lambda: self.habilitar_borrador(15))
        submenu_borrador.add_command(label="Borrador grande", command=lambda: self.habilitar_borrador(30))

        paleta_button = tk.Button(self.dynamic_buttons_frame, cursor="hand2", text="Paleta", image=self.imagen10, border=0, background="white")
        paleta_button.place(x=100, y=120, width=100)
        SimilarTooltip(paleta_button, "Paleta")

        # Desvincular eventos de dibujo de líneas
        self.canvas.bind("<ButtonPress-1>")
        self.canvas.bind("<B1-Motion>")
        self.canvas.bind("<ButtonRelease-1>")

        # Enlazar eventos de
        self.canvas.bind("<ButtonPress-1>")
        self.canvas.bind("<B1-Motion>")
        self.canvas.bind("<ButtonRelease-1>")
        
        # Borrar el menú de formas si existe
        if hasattr(self, "menu_formas"):
            self.menu_formas.delete(0, "end")

        # Establecer el foco en el botón de formas
        self.formas_button.focus_set()

    def guardar_imagen(self):
        # Capturar la imagen del canvas
        x = self.root.winfo_rootx() + self.canvas.winfo_x()
        y = self.root.winfo_rooty() + self.canvas.winfo_y()
        x1 = x + self.canvas.winfo_width()
        y1 = y + self.canvas.winfo_height()
        ImageGrab.grab().crop((x, y, x1, y1)).save("mi_dibujo.png")

    def habilitar_escritura(self):
        # Cambiar el estado de escritura a True
        self.escribiendo = True

        # Crear una entrada de texto en el canvas
        self.texto_entry = tk.Entry(self.canvas, bd=2, relief=tk.SOLID)
        self.texto_entry.place(x=0, y=0)

        # Establecer el foco en la entrada de texto
        self.texto_entry.focus_set()

        # Enlazar evento de Enter para insertar texto
        self.texto_entry.bind("<Return>", self.insertar_texto)

    def insertar_texto(self, event):
        # Obtener el texto ingresado
        texto = self.texto_entry.get()

        # Dibujar el texto en el canvas
        self.canvas.create_text(self.x_inicial, self.y_inicial, text=texto)

        # Eliminar la entrada de texto
        self.texto_entry.destroy()

        # Restablecer el estado de escritura a False
        self.escribiendo = False

    def habilitar_borrador(self, tamaño):
        # Establecer el tamaño del borrador
        self.borrador_tamaño = tamaño

        # Activar el borrador
        self.borrando = True

    def iniciar_dibujo_forma(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        self.x_inicial = event.x
        self.y_inicial = event.y

    def dibujar_forma(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        x_final = event.x
        y_final = event.y

        # Dibujar la forma seleccionada
        if self.forma_seleccionada == "cuadrado":
            self.canvas.create_rectangle(self.x_inicial, self.y_inicial, x_final, y_final, outline="black", width=2)
        elif self.forma_seleccionada == "circulo":
            self.canvas.create_oval(self.x_inicial, self.y_inicial, x_final, y_final, outline="black", width=2)
        elif self.forma_seleccionada == "triangulo":
            self.canvas.create_polygon(self.x_inicial, self.y_inicial, x_final, y_final, outline="black", width=2)
        elif self.forma_seleccionada == "linea":
            self.canvas.create_line(self.x_inicial, self.y_inicial, x_final, y_final, fill="black", width=2)

    def finalizar_dibujo_forma(self, event):
        if self.escribiendo or self.objeto_seleccionado or self.borrando:  
            return
        self.x_inicial = None
        self.y_inicial = None
        self.forma_seleccionada = None

    def main(self):
        self.root.mainloop()

if __name__ == "__main__":
    root = tk.Tk()
    paint_app = Paint(root)
    paint_app.main()


