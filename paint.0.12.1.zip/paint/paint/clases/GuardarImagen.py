

from PIL import ImageGrab

class GuardarImagen:
    def __init__(self, canvas):
        self.canvas = canvas
        self.filename = None
        self.x = None
        self.y = None
        self.x1 = None
        self.y1 = None

    def get_filename(self):
        return self.filename

    def set_filename(self, filename):
        self.filename = filename

    def guardar(self):
        if self.filename:
            self.x = self.canvas.winfo_rootx() + self.canvas.winfo_x()
            self.y = self.canvas.winfo_rooty() + self.canvas.winfo_y()
            self.x1 = self.x + self.canvas.winfo_width()
            self.y1 = self.y + self.canvas.winfo_height()
            image = ImageGrab.grab(bbox=(self.x, self.y, self.x1, self.y1))
            image = image.crop((0, 0, 800, 520))
            image.save(self.filename)