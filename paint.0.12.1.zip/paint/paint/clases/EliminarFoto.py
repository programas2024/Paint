class EliminarFoto:
    def __init__(self, parent):
        self.parent = parent

    def eliminar_foto(self, event):
        x, y = event.x, event.y
        # Verificar si el cursor está sobre una imagen importada
        for label, (img_x, img_y) in zip(self.parent.image_labels, self.parent.image_positions):
            img_width = label.winfo_width()
            img_height = label.winfo_height()
            if img_x < x < img_x + img_width and img_y < y < img_y + img_height:
                label.destroy()
                self.parent.image_labels.remove(label)
                break